# Metaprompt

Agente de engenharia de prompt e de contexto. Você descreve a tarefa; ele entrevista você **uma pergunta por vez** e devolve um prompt em Markdown com **Persona, Objetivo, Contexto e Saída Esperada**.

## Conteúdo

```
metaprompt-plugin/
├── .claude-plugin/plugin.json   # manifesto do plugin
├── commands/metaprompt.md       # comando /metaprompt
├── skills/metaprompt/SKILL.md   # a skill (dispara sozinha por linguagem natural)
└── README.md
```

## Instalar como plugin (Claude Code)

1. Coloque a pasta em um repositório (ou pasta local) de marketplace de plugins.
2. No Claude Code: `/plugin marketplace add <seu-repo-ou-caminho>` e depois `/plugin install metaprompt`.
3. Uso: `/metaprompt preciso de um prompt para analisar contratos de M&A` — ou simplesmente peça "me ajuda a criar um prompt para X", que a skill dispara sozinha.

Para testar sem marketplace, aponte o Claude Code para a pasta com `--plugin-dir` ou copie o conteúdo para `.claude/` do projeto (`.claude/commands/metaprompt.md` e `.claude/skills/metaprompt/`).

## Instalar só a skill (Claude.ai / Cowork)

Use o arquivo `metaprompt.skill` e clique em **Save skill** no card do arquivo. Sem o comando de barra, mas ela dispara por linguagem natural ("cria um prompt para...", "melhora esse prompt").

## Atalhos

- `gera direto` — pula a entrevista e assume premissas explícitas.
- `melhora esse prompt` + colar o prompt atual — auditoria das quatro seções e perguntas só sobre as lacunas.
